#pragma once
#include <Windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include "kiero/kiero.h"
#include "imgui/imgui.h"
#include "imgui/imgui_impl_win32.h"
#include "imgui/imgui_impl_dx11.h"

typedef HRESULT(__stdcall* Present) (IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags);
typedef LRESULT(CALLBACK* WNDPROC)(HWND, UINT, WPARAM, LPARAM);
typedef uintptr_t PTR;

/* SDK */
#include "SDK/Engine_classes.hpp"
#include "SDK/BP_ThermalImager_classes.hpp"
#include "SDK/BP_GameState_classes.hpp"
#include "SDK/BP_Kangaroo_classes.hpp"
#include "SDK/WBP_AnimalInfo_classes.hpp";

#define stofn(x) SDK::UKismetStringLibrary::Conv_StringToName(x)

namespace VisualsHandler
{
	ImFont *drawFont;
	ImFont *outlineFont;

	void DrawFilledRect( ImDrawList *dl, int x, int y, int w, int h, ImColor color )
	{
		dl->AddRectFilled( ImVec2( x, y ), ImVec2( x + w, y + h ), color );
	}

	void DrawFilledBox( ImDrawList *dl, SDK::FVector2D posA, SDK::FVector2D posB, ImColor color, float rounding = 1.f )
	{
		dl->AddRectFilled( ImVec2( posA.X, posA.Y ), ImVec2( posB.X, posB.Y ), color, rounding );
	}

	ImVec4 getColor( float color[4] )
	{
		return ImVec4(
			color[0],
			color[1],
			color[2],
			color[3]
		);
	}

	void DrawNametag( std::string text, SDK::FVector2D pos, float color[4] )
	{
		ImVec4 color_ = getColor( color );

		ImGui::GetForegroundDrawList( )->AddText(
			ImVec2( pos.X, pos.Y ),
			(ImColor)color_,
			text.c_str( )
		);
	}

	void DrawCornerBox( ImDrawList *dl, int x, int y, int w, int h, int borderPx, float color_[4] )
	{
		ImColor color = ImColor( 255, 255, 255, 255 );
		/* (ImColor)getColor(color_); */

		VisualsHandler::DrawFilledRect( dl, x + borderPx, y, w / 3, borderPx, color );
		VisualsHandler::DrawFilledRect( dl, x + w - w / 3 + borderPx, y, w / 3, borderPx, color );
		VisualsHandler::DrawFilledRect( dl, x, y, borderPx, h / 3, color );
		VisualsHandler::DrawFilledRect( dl, x, y + h - h / 3 + borderPx * 2, borderPx, h / 3, color );
		VisualsHandler::DrawFilledRect( dl, x + borderPx, y + h + borderPx, w / 3, borderPx, color );
		VisualsHandler::DrawFilledRect( dl, x + w - w / 3 + borderPx, y + h + borderPx, w / 3, borderPx, color );
		VisualsHandler::DrawFilledRect( dl, x + w + borderPx, y, borderPx, h / 3, color );
		VisualsHandler::DrawFilledRect( dl, x + w + borderPx, y + h - h / 3 + borderPx * 2, borderPx, h / 3, color );
	}

	void DrawCornerBox( ImDrawList *dl, int x, int y, int w, int h, int borderPx, ImColor color )
	{
		VisualsHandler::DrawFilledRect( dl, x + borderPx, y, w / 3, borderPx, color );
		VisualsHandler::DrawFilledRect( dl, x + w - w / 3 + borderPx, y, w / 3, borderPx, color );
		VisualsHandler::DrawFilledRect( dl, x, y, borderPx, h / 3, color );
		VisualsHandler::DrawFilledRect( dl, x, y + h - h / 3 + borderPx * 2, borderPx, h / 3, color );
		VisualsHandler::DrawFilledRect( dl, x + borderPx, y + h + borderPx, w / 3, borderPx, color );
		VisualsHandler::DrawFilledRect( dl, x + w - w / 3 + borderPx, y + h + borderPx, w / 3, borderPx, color );
		VisualsHandler::DrawFilledRect( dl, x + w + borderPx, y, borderPx, h / 3, color );
		VisualsHandler::DrawFilledRect( dl, x + w + borderPx, y + h - h / 3 + borderPx * 2, borderPx, h / 3, color );
	}

	void OutlinedText( std::string text, ImDrawList *dl, ImVec2 pos, ImColor color )
	{

		dl->AddText( ImVec2( pos.x + 1, pos.y + 1 ), IM_COL32_BLACK, text.c_str( ) );
		dl->AddText( ImVec2( pos.x - 1, pos.y - 1 ), IM_COL32_BLACK, text.c_str( ) );
		dl->AddText( ImVec2( pos.x + 1, pos.y - 1 ), IM_COL32_BLACK, text.c_str( ) );
		dl->AddText( ImVec2( pos.x - 1, pos.y + 1 ), IM_COL32_BLACK, text.c_str( ) );

		dl->AddText( ImVec2( pos.x + 1, pos.y ), IM_COL32_BLACK, text.c_str( ) );
		dl->AddText( ImVec2( pos.x - 1, pos.y ), IM_COL32_BLACK, text.c_str( ) );
		dl->AddText( ImVec2( pos.x, pos.y - 1 ), IM_COL32_BLACK, text.c_str( ) );
		dl->AddText( ImVec2( pos.x, pos.y + 1 ), IM_COL32_BLACK, text.c_str( ) );

		dl->AddText( pos, color, text.c_str( ) );
	}

	void DrawNametag( ImDrawList *dl, SDK::FVector2D position, std::string text, ImColor color )
	{
		ImGui::PushFont( drawFont );
		dl->AddText(
			ImVec2( position.X, position.Y ),
			color,
			text.c_str( )
		);
		ImGui::PopFont( );
	}

	void DrawLine( SDK::FVector2D posA, SDK::FVector2D posB, ImVec4 color, bool outline = false, float t = 1.f )
	{
		if ( outline )
			ImGui::GetForegroundDrawList( )->AddLine( ImVec2( posA.X, posA.Y ), ImVec2( posB.X, posB.Y ), ImColor( 0.f, 0.f, 0.f ), t + 1.f );
		ImGui::GetForegroundDrawList( )->AddLine( ImVec2( posA.X, posA.Y ), ImVec2( posB.X, posB.Y ), ImColor( color ), t );
	}

	void Draw3DBox( SDK::FVector &center, SDK::FVector &Bounds, SDK::APlayerController *Controller, float color_[4] )
	{
		ImColor color = (ImColor)getColor( color_ );

		const float wX = ( center.X + Bounds.X ) - ( center.X - Bounds.X );
		const float wY = ( center.Y + Bounds.Y ) - ( center.Y - Bounds.Y );

		SDK::FVector Top{ center.X, center.Y, center.Z + Bounds.Z };
		SDK::FVector Bottom{ center.X, center.Y, center.Z - Bounds.Z };

		SDK::FVector a1 = { center.X - wX / 2, center.Y + wY / 2, Bottom.Z };
		SDK::FVector a2 = { center.X + wX / 2, center.Y + wY / 2, Bottom.Z };
		SDK::FVector a3 = { center.X - wX / 2, center.Y - wY / 2, Bottom.Z };
		SDK::FVector a4 = { center.X + wX / 2, center.Y - wY / 2, Bottom.Z };

		SDK::FVector b1 = { center.X - wX / 2, center.Y + wY / 2, Top.Z };
		SDK::FVector b2 = { center.X + wX / 2, center.Y + wY / 2, Top.Z };
		SDK::FVector b3 = { center.X - wX / 2, center.Y - wY / 2, Top.Z };
		SDK::FVector b4 = { center.X + wX / 2, center.Y - wY / 2, Top.Z };

		SDK::FVector2D a1w2s{};
		SDK::FVector2D a2w2s{};
		SDK::FVector2D a3w2s{};
		SDK::FVector2D a4w2s{};

		SDK::FVector2D b1w2s{};
		SDK::FVector2D b2w2s{};
		SDK::FVector2D b3w2s{};
		SDK::FVector2D b4w2s{};

		if ( Controller->ProjectWorldLocationToScreen( a1, &a1w2s, false ) && Controller->ProjectWorldLocationToScreen( a2, &a2w2s, false )
			&& Controller->ProjectWorldLocationToScreen( a3, &a3w2s, false ) && Controller->ProjectWorldLocationToScreen( a4, &a4w2s, false )
			&& Controller->ProjectWorldLocationToScreen( b1, &b1w2s, false ) && Controller->ProjectWorldLocationToScreen( b2, &b2w2s, false )
			&& Controller->ProjectWorldLocationToScreen( b3, &b3w2s, false ) && Controller->ProjectWorldLocationToScreen( b4, &b4w2s, false ) )
		{
			VisualsHandler::DrawLine( a1w2s, a2w2s, color );
			VisualsHandler::DrawLine( a2w2s, a4w2s, color );
			VisualsHandler::DrawLine( a4w2s, a3w2s, color );
			VisualsHandler::DrawLine( a3w2s, a1w2s, color );

			VisualsHandler::DrawLine( b1w2s, b2w2s, color );
			VisualsHandler::DrawLine( b2w2s, b4w2s, color );
			VisualsHandler::DrawLine( b4w2s, b3w2s, color );
			VisualsHandler::DrawLine( b3w2s, b1w2s, color );

			VisualsHandler::DrawLine( a1w2s, b1w2s, color );
			VisualsHandler::DrawLine( a2w2s, b2w2s, color );
			VisualsHandler::DrawLine( a3w2s, b3w2s, color );
			VisualsHandler::DrawLine( a4w2s, b4w2s, color );
		}
	}


	void Draw3DBox( SDK::FVector &center, SDK::FVector &Bounds, SDK::APlayerController *Controller, ImVec4 color )
	{
		const float wX = ( center.X + Bounds.X ) - ( center.X - Bounds.X );
		const float wY = ( center.Y + Bounds.Y ) - ( center.Y - Bounds.Y );

		SDK::FVector Top{ center.X, center.Y, center.Z + Bounds.Z };
		SDK::FVector Bottom{ center.X, center.Y, center.Z - Bounds.Z };

		SDK::FVector a1 = { center.X - wX / 2, center.Y + wY / 2, Bottom.Z };
		SDK::FVector a2 = { center.X + wX / 2, center.Y + wY / 2, Bottom.Z };
		SDK::FVector a3 = { center.X - wX / 2, center.Y - wY / 2, Bottom.Z };
		SDK::FVector a4 = { center.X + wX / 2, center.Y - wY / 2, Bottom.Z };

		SDK::FVector b1 = { center.X - wX / 2, center.Y + wY / 2, Top.Z };
		SDK::FVector b2 = { center.X + wX / 2, center.Y + wY / 2, Top.Z };
		SDK::FVector b3 = { center.X - wX / 2, center.Y - wY / 2, Top.Z };
		SDK::FVector b4 = { center.X + wX / 2, center.Y - wY / 2, Top.Z };

		SDK::FVector2D a1w2s{};
		SDK::FVector2D a2w2s{};
		SDK::FVector2D a3w2s{};
		SDK::FVector2D a4w2s{};

		SDK::FVector2D b1w2s{};
		SDK::FVector2D b2w2s{};
		SDK::FVector2D b3w2s{};
		SDK::FVector2D b4w2s{};

		if ( Controller->ProjectWorldLocationToScreen( a1, &a1w2s, false ) && Controller->ProjectWorldLocationToScreen( a2, &a2w2s, false )
			&& Controller->ProjectWorldLocationToScreen( a3, &a3w2s, false ) && Controller->ProjectWorldLocationToScreen( a4, &a4w2s, false )
			&& Controller->ProjectWorldLocationToScreen( b1, &b1w2s, false ) && Controller->ProjectWorldLocationToScreen( b2, &b2w2s, false )
			&& Controller->ProjectWorldLocationToScreen( b3, &b3w2s, false ) && Controller->ProjectWorldLocationToScreen( b4, &b4w2s, false ) )
		{
			VisualsHandler::DrawLine( a1w2s, a2w2s, color );
			VisualsHandler::DrawLine( a2w2s, a4w2s, color );
			VisualsHandler::DrawLine( a4w2s, a3w2s, color );
			VisualsHandler::DrawLine( a3w2s, a1w2s, color );

			VisualsHandler::DrawLine( b1w2s, b2w2s, color );
			VisualsHandler::DrawLine( b2w2s, b4w2s, color );
			VisualsHandler::DrawLine( b4w2s, b3w2s, color );
			VisualsHandler::DrawLine( b3w2s, b1w2s, color );

			VisualsHandler::DrawLine( a1w2s, b1w2s, color );
			VisualsHandler::DrawLine( a2w2s, b2w2s, color );
			VisualsHandler::DrawLine( a3w2s, b3w2s, color );
			VisualsHandler::DrawLine( a4w2s, b4w2s, color );
		}
	}
}

namespace ModuleHelper
{

	SDK::FName head = stofn( L"head" );

	SDK::FName ball_l_end = stofn( L"ball_l_end" );
	SDK::FName ball_r_end = stofn( L"ball_r_end" );

	void draw_box_esp( SDK::USkeletalMeshComponent *mesh, SDK::APlayerController *lpc, ImColor color )
	{
		SDK::FVector2D Top;
		SDK::FVector2D Bottom;

		SDK::FVector actorHead = mesh->GetSocketLocation( head );

		SDK::FVector actor_ball_l_end = mesh->GetSocketLocation( ball_l_end );
		SDK::FVector actor_ball_r_end = mesh->GetSocketLocation( ball_r_end );

		SDK::FVector actorOrigin = ( actor_ball_l_end + actor_ball_r_end ) / 2;

		if ( lpc->ProjectWorldLocationToScreen( actorHead, &Top, true ) && lpc->ProjectWorldLocationToScreen( actorOrigin, &Bottom, true ) )
		{
			const float h = Bottom.Y - Top.Y;
			const float w = h * 0.3f;

			VisualsHandler::DrawCornerBox( ImGui::GetForegroundDrawList( ), Top.X - w + 1, Top.Y + 1, w * 1.8f - 2, h - 2, 1, ImColor( 255, 255, 255, 180 ) );
			VisualsHandler::DrawCornerBox( ImGui::GetForegroundDrawList( ), Top.X - w - 1, Top.Y - 1, w * 1.8f + 2, h + 2, 1, ImColor( 255, 255, 255, 180 ) );
			VisualsHandler::DrawCornerBox( ImGui::GetForegroundDrawList( ), Top.X - w, Top.Y, w * 1.8f, h, 1, ImColor( 255, 0, 0, 255 ) );
		}
	}
}

