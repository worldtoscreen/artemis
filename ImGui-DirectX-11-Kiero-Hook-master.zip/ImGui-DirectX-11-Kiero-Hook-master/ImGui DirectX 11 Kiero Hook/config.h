#pragma once
#include "imgui/imgui.h"
#include <string>

namespace artemis
{
	bool cheatWindow = false;

	namespace menu
	{
		bool displayMenu = true;
	}

	namespace config
	{
		/*
		* Explorer
		* 
		* Used by developers (and players I guess) to find actor names
		*/
		namespace explorer
		{
			bool enabled = false;
			bool show_full_names = true;
			char actor_filter[64] = "";

			float distance_limit = 3000;

			bool tracers = false;
			bool nametags = false;
			bool boxes_3d = false;

			namespace colors
			{
				ImVec4 tracersColor = ImVec4( 1.f, 1.f, 1.f, 1.f );
				ImVec4 nametagsColor = ImVec4( 1.f, 1.f, 1.f, 1.f );
				ImVec4 boxes3DColor = ImVec4( 1.f, 1.f, 1.f, 1.f );
			}
		}

		namespace visuals
		{
			bool corner_esp = false;
			bool nametags = false;
			bool background_esp = false;

			bool flags_distance = false;
			bool flags_infected = false;
			bool flags_showTagName = false;
			bool flags_resting = false;
			bool flags_current_food = false;
			bool flags_is_debug = false;
			bool flags_can_eat = false;
			bool flags_is_full = false;
			bool flags_eating_status = false;
			bool flags_tranq = false;
			bool flags_fighting = false; 

			bool display_symptoms = false;

			namespace colors
			{
				ImVec4 cornerEspColor = ImVec4( 1, 1, 1, 1 );
				ImVec4 backgroundEspColor = ImVec4( 1, 1, 1, 0.15f );
				ImVec4 nametagsColor = ImVec4( 1, 1, 1, 1 );
			}
		}

		namespace fighting
		{
			bool auto_kill_on_infected = false;
		}
	}
}