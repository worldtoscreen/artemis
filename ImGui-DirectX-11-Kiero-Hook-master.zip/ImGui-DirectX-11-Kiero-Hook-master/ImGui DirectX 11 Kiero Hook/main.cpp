#include "includes.h"
#include "config.h"

// #define DEBUG

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

Present oPresent;
HWND window = NULL;
WNDPROC oWndProc;
ID3D11Device* pDevice = NULL;
ID3D11DeviceContext* pContext = NULL;
ID3D11RenderTargetView* mainRenderTargetView;

HMODULE hModule = NULL;

void InitImGui()
{
	ImGui::CreateContext();
	ImGuiIO& io = ImGui::GetIO();
	io.ConfigFlags = ImGuiConfigFlags_NoMouseCursorChange;
	ImGui_ImplWin32_Init(window);
	ImGui_ImplDX11_Init(pDevice, pContext);

#ifdef DEBUG
	AllocConsole( );
	FILE *Dummy;
	freopen_s( &Dummy, "CONOUT$", "w", stdout );
	freopen_s( &Dummy, "CONIN$", "r", stdin );
#endif

}

void cheatCallback( )
{
	/* Cheat Logic */

	if ( GetAsyncKeyState( VK_DELETE ) & 1 )
	{
		
	}

	if ( GetAsyncKeyState( VK_INSERT ) & 1 )
	{
		artemis::menu::displayMenu = !artemis::menu::displayMenu;
	}

	bool valid = false;
	std::string invalidNotifier = "null";

	SDK::UWorld *world = SDK::UWorld::GetWorld( );
	SDK::UEngine *engine = SDK::UEngine::GetEngine( );

	SDK::ULocalPlayer *localPlayer = nullptr;
	SDK::APlayerController *localController = nullptr;

	

	UC::TArray<SDK::AActor *> actors = {};

	SDK::ABP_ThermalImager_C *imager = nullptr; // used to get animals

	/* This may seem overdone but to avoid crashes it's good practice */
	if ( world && engine )
	{
		SDK::ULevel *pl = world->PersistentLevel;
		if ( pl )
		{
			if ( pl->Actors )
			{
				actors = pl->Actors;
				SDK::UGameInstance *gi = world->OwningGameInstance;
				if ( gi )
				{
					UC::TArray<SDK::ULocalPlayer *> localPlayerArray = gi->LocalPlayers;
					if ( localPlayerArray && localPlayerArray.Num( ) > 0 )
					{
						localPlayer = localPlayerArray[0];
						if ( localPlayer )
						{
							localController = localPlayer->PlayerController;
							if ( localController )
							{
								for ( int i = 0; i < actors.Num( ); i++ )
								{
									SDK::AActor* actor = actors[i];
									if ( !actor )
										continue;

									if ( actor->Class == SDK::ABP_ThermalImager_C::StaticClass( ) )
									{
										imager = (SDK::ABP_ThermalImager_C *)actor;
									}
										
								}
								valid = true;
							}
							else { invalidNotifier = "localPlayerController is invalid"; }
						}
						else { invalidNotifier = "localPlayer from localPlayerArray is invalid"; }
					}
					else { invalidNotifier = "gameInstance->LocalPlayers is idle / empty"; }
				}
				else { invalidNotifier = "OwningGameInstance is idle"; }
			}
			else { invalidNotifier = "No actors in level"; }
		}
		else { invalidNotifier = "PersistentLevel is idle"; }
	}
	else { invalidNotifier = "World or Engine is idle"; }

	if ( !valid )
	{
		VisualsHandler::OutlinedText( invalidNotifier, ImGui::GetForegroundDrawList( ), ImVec2( 50, 50 ), ImColor( 255, 0, 0, 255 ) );
		return;
	}

	ImVec2 screenSize = ImGui::GetIO( ).DisplaySize;
	ImVec2 screenCenter = { screenSize.x / 2.f, screenSize.y / 2.f };
	SDK::FVector2D sdkScreenCenter = { screenCenter.x, screenCenter.y };

	if ( artemis::config::explorer::enabled && artemis::menu::displayMenu )
		ImGui::Begin( "Explorer Output" );

	if ( ( GetAsyncKeyState( VK_F1 ) & 1 ) && ( GetAsyncKeyState( VK_SHIFT ) & 1 ) && ( !artemis::cheatWindow ) )
	{
		artemis::cheatWindow = true;
		Beep( 500, 600 );
		Beep( 250, 1000 );
		localController->EnableCheats( );
	}

	for ( int l = 0; l < world->Levels.Num( ); l++ )
	{
		SDK::ULevel *level = world->Levels[l];
		if ( !level )
			continue;

		for ( int a = 0; a < level->Actors.Num( ); a++ )
		{
			SDK::AActor *actor = level->Actors[a];
			if ( !actor )
				continue;

			if ( actor->IsA( SDK::ABP_AnimalBasePawn_C::StaticClass( ) ) )
			{
				SDK::ABP_AnimalBasePawn_C *animal = (SDK::ABP_AnimalBasePawn_C *)actor;
				SDK::USkeletalMeshComponent *skel = nullptr;

				animal->GetSkeletalMeshComponent(&skel);

				if ( !animal || animal->IsDead )
					continue;

				if ( artemis::config::fighting::auto_kill_on_infected && animal->bAnimalInfected )
					animal->Kill( );	

				SDK::FVector location, bounds;
				SDK::FVector2D screenPosition;

				actor->GetActorBounds( true, &location, &bounds, false );
				bool canDraw = localController->ProjectWorldLocationToScreen( location, &screenPosition, true ) && skel != nullptr;

				ImVec2 iScreenPositon = { (float)screenPosition.X, (float)screenPosition.Y };

				float distance = localController->GetDistanceTo( actor );

				std::vector<std::string> flags = { };

				if ( artemis::config::visuals::flags_distance )
				{
					std::string flag = std::to_string(distance) + "m";
					flags.push_back( flag );
				}

				if ( artemis::config::visuals::flags_infected && animal->bAnimalInfected )
				{
					flags.push_back( "infected" );
				}

				if ( artemis::config::visuals::flags_showTagName )
				{
					flags.push_back( animal->StateTag.TagName.ToString( ) );
				}

				if ( artemis::config::visuals::flags_resting && animal->Is_Animal_Sleep )
				{
					flags.push_back( "eepy" );
				}

				if ( artemis::config::visuals::flags_current_food )
				{
					double current_feed = animal->CurrentEatenFood;
					flags.push_back( std::to_string( current_feed ) );
				}

				if ( artemis::config::visuals::flags_is_debug && animal->Is_Debug )
				{
					flags.push_back( "DEBUG" );
				}

				if ( artemis::config::visuals::flags_can_eat && animal->CanEat )
				{
					flags.push_back( "Can Eat" );
				}

				if ( artemis::config::visuals::flags_is_full && animal->IsAnimalFull )
				{
					flags.push_back( "Is Full" );
				}

				if ( artemis::config::visuals::flags_eating_status )
				{
					SDK::E_ActionEatingStatus status = animal->EatingStatus;
					std::string flag = "";

					switch ( status )
					{
					case SDK::E_ActionEatingStatus::Eating:
						flag = "eating";
						break;

					case SDK::E_ActionEatingStatus::Pooping:
						flag = "shitting";
						break;

					case SDK::E_ActionEatingStatus::Vomit:
						flag = "throwing up";
						break;

					case SDK::E_ActionEatingStatus::Done:
						flag = "done eating";
						break;

					default:
						flag = "unknonw";
					}

					flags.push_back( flag );
				}

				if ( artemis::config::visuals::flags_tranq && animal->Tranquilized )
				{
					flags.push_back( "tranquilized" );
				}

				if ( artemis::config::visuals::flags_fighting && animal->Fighting )
				{
					flags.push_back( "fighting" );
				}

				/*
				if ( artemis::config::visuals::flags_disase_status )
				{
					std::string flag = "null";
					SDK::UAnimalDiseaseDataAsset *dd = animal->CurrentDiseaseData;

					flags.push_back( flag );
				}
				*/

				if ( canDraw )
				{

#ifdef DEBUG
					for ( int b = 0; b < skel->GetNumBones( ); b++ )
					{
						SDK::FName boneName = skel->GetBoneName( b );
						SDK::FVector boneLocation = skel->GetSocketLocation( boneName );

						SDK::FVector2D boneScreenPos;
						localController->ProjectWorldLocationToScreen( boneLocation, &boneScreenPos, true );

						std::string boneLabel = std::to_string( b );
						VisualsHandler::OutlinedText( boneLabel, ImGui::GetForegroundDrawList( ), ImVec2( boneScreenPos.X, boneScreenPos.Y ), ImColor( 255, 255, 255, 255 ) );
						
						std::cout << "Bone Index : b=" << b << " | Bone Name: boneName=" << boneName.ToString( ) << std::endl;

					} std::cout << "\n\n" << std::endl;
#endif

					float flag_text_offset = 0.f;
					for ( std::string flag : flags )
					{
						SDK::FVector pos = location;

						SDK::FVector2D flagSP;
						localController->ProjectWorldLocationToScreen( pos, &flagSP, true );

						ImVec2 iFlagSP = { (float)flagSP.X, (float)flagSP.Y };
						iFlagSP.y += flag_text_offset;

						VisualsHandler::OutlinedText( flag, ImGui::GetForegroundDrawList( ), iFlagSP, ImColor( 255, 255, 255, 255 ) );

						ImVec2 size = ImGui::CalcTextSize( flag.c_str( ) );
						flag_text_offset += size.y;
					}

					if ( artemis::config::visuals::nametags )
					{
						SDK::FVector pos = location;
						location.Y -= bounds.Y;

						SDK::FVector2D nametagPos;
						std::string animalName = animal->AnimalName.ToString( );

						localController->ProjectWorldLocationToScreen( pos, &nametagPos, true );

						nametagPos.X -= 150;
						nametagPos.Y += 15;

						VisualsHandler::OutlinedText( animalName, ImGui::GetForegroundDrawList( ), ImVec2( nametagPos.X, nametagPos.Y ), ImColor( 255, 255, 255, 255 ) );
					}

					if ( artemis::config::visuals::display_symptoms )
					{

					}
				}

			}

			if ( artemis::config::explorer::enabled )
			{

				SDK::FVector location, bounds;
				SDK::FVector2D screenPosition;

				actor->GetActorBounds( true, &location, &bounds, false );
				bool canDraw = localController->ProjectWorldLocationToScreen( location, &screenPosition, true );

				ImVec2 iScreenPositon = { (float)screenPosition.X, (float)screenPosition.Y };

				float distance = localController->GetDistanceTo( actor );

				std::string actorName = actor->GetName( );
				std::string actorFullName = actor->GetFullName( );

				std::string renderName = artemis::config::explorer::show_full_names ? actorFullName : actorName;

				if ( true ) /* distance <= artemis::config::explorer::distance_limit - removed for testing*/
				{
					if ( artemis::config::explorer::actor_filter == "" || renderName.find( std::string( artemis::config::explorer::actor_filter ) ) != std::string::npos )
					{

						if ( artemis::config::explorer::enabled && artemis::menu::displayMenu )
							ImGui::Text( renderName.c_str( ) );

						if ( canDraw )
						{
							if ( artemis::config::explorer::tracers )
							{
								VisualsHandler::DrawLine( screenPosition, sdkScreenCenter, artemis::config::explorer::colors::tracersColor, true );
							}
							if ( artemis::config::explorer::boxes_3d )
							{
								VisualsHandler::Draw3DBox( location, bounds, localController, artemis::config::explorer::colors::boxes3DColor );
							}
							if ( artemis::config::explorer::nametags ) /* nametags are last so they render on top */
							{
								VisualsHandler::OutlinedText( renderName, ImGui::GetForegroundDrawList( ), iScreenPositon, (ImColor)artemis::config::explorer::colors::nametagsColor );
							}
						}

					}
				}
			}
		}
	}

	if ( artemis::config::explorer::enabled && artemis::menu::displayMenu )
		ImGui::End();
}

LRESULT __stdcall WndProc(const HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

	if (true && ImGui_ImplWin32_WndProcHandler(hWnd, uMsg, wParam, lParam))
		return true;

	return CallWindowProc(oWndProc, hWnd, uMsg, wParam, lParam);
}

bool init = false;
HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags)
{
	if (!init)
	{
		if (SUCCEEDED(pSwapChain->GetDevice(__uuidof(ID3D11Device), (void**)& pDevice)))
		{
			pDevice->GetImmediateContext(&pContext);
			DXGI_SWAP_CHAIN_DESC sd;
			pSwapChain->GetDesc(&sd);
			window = sd.OutputWindow;
			ID3D11Texture2D* pBackBuffer;
			pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)& pBackBuffer);
			pDevice->CreateRenderTargetView(pBackBuffer, NULL, &mainRenderTargetView);
			pBackBuffer->Release();
			oWndProc = (WNDPROC)SetWindowLongPtr(window, GWLP_WNDPROC, (LONG_PTR)WndProc);
			InitImGui();
			init = true;
		}

		else
			return oPresent(pSwapChain, SyncInterval, Flags);
	}

	ImGui_ImplDX11_NewFrame();
	ImGui_ImplWin32_NewFrame();
	ImGui::NewFrame();

	if ( artemis::menu::displayMenu )
	{
		ImGui::Begin( "artemis" );
		ImGui::Text( "Last Updated: 10/1/2024" );
		ImGui::Text( "Written by WorldToScreen on discord using kierohook." );

		if ( ImGui::BeginTabBar( "modules" ) )
		{
			/* Update: https://steamdb.info/app/2458560/ */

			if ( ImGui::BeginTabItem( "Explorer" ) )
			{
				ImGui::Text( "General" );

				ImGui::Checkbox( "Enabled", &artemis::config::explorer::enabled );
				ImGui::Checkbox( "Use Full Names (to show hierarchy)", &artemis::config::explorer::show_full_names );
				ImGui::InputText( "Actor Filter", artemis::config::explorer::actor_filter, sizeof( artemis::config::explorer::actor_filter ) );
				ImGui::SliderFloat( "Max Distance", &artemis::config::explorer::distance_limit, 100.f, 100000.f );

				ImGui::Separator( );
				ImGui::Text( "Visuals" );

				ImGui::Checkbox( "Tracers", &artemis::config::explorer::tracers ); ImGui::SameLine( ); ImGui::ColorEdit4( "##explorer_tracers_color", (float *)&artemis::config::explorer::colors::nametagsColor, ImGuiColorEditFlags_NoAlpha );
				ImGui::Checkbox( "3D Boxes", &artemis::config::explorer::boxes_3d ); ImGui::SameLine( ); ImGui::ColorEdit4( "##explorer_3dbox_color", (float *)&artemis::config::explorer::colors::boxes3DColor, ImGuiColorEditFlags_NoAlpha );
				ImGui::Checkbox( "Nametags", &artemis::config::explorer::nametags ); ImGui::SameLine( ); ImGui::ColorEdit4( "##explorer_nametag_color", (float *)&artemis::config::explorer::colors::nametagsColor, ImGuiColorEditFlags_NoAlpha );

				ImGui::EndTabItem( );
			}

			if ( ImGui::BeginTabItem( "Visuals" ) )
			{
#ifdef DEBUG
				ImGui::Checkbox( "Corner ESP", &artemis::config::visuals::corner_esp ); ImGui::SameLine( ); ImGui::ColorEdit4( "##visualscorneresp", (float *)&artemis::config::visuals::colors::cornerEspColor, ImGuiColorEditFlags_HEX );
				ImGui::Checkbox( "Background ESP", &artemis::config::visuals::background_esp ); ImGui::SameLine( ); ImGui::ColorEdit4( "##backgroundesp", (float *)&artemis::config::visuals::colors::backgroundEspColor, ImGuiColorEditFlags_HEX );
#endif
				ImGui::Checkbox( "Name Tags", &artemis::config::visuals::nametags ); ImGui::SameLine( ); ImGui::ColorEdit4( "##nametagsesp", (float *)&artemis::config::visuals::colors::nametagsColor, ImGuiColorEditFlags_HEX );

				ImGui::Checkbox( "Show Distance", &artemis::config::visuals::flags_distance );
				ImGui::Checkbox( "Show Infected", &artemis::config::visuals::flags_infected );
				ImGui::Checkbox( "Show Tag Name", &artemis::config::visuals::flags_showTagName );
				ImGui::Checkbox( "Show Resting", &artemis::config::visuals::flags_resting );
				ImGui::Checkbox( "Show Current Food", &artemis::config::visuals::flags_current_food );
				ImGui::Checkbox( "Debug Mode", &artemis::config::visuals::flags_is_debug );
				ImGui::Checkbox( "Can Eat", &artemis::config::visuals::flags_can_eat );
				ImGui::Checkbox( "Is Full", &artemis::config::visuals::flags_is_full );
				ImGui::Checkbox( "Eating Status", &artemis::config::visuals::flags_eating_status );
				ImGui::Checkbox( "Tranq Status", &artemis::config::visuals::flags_tranq );
				ImGui::Checkbox( "Fighting Status", &artemis::config::visuals::flags_fighting );

				ImGui::EndTabItem( );
			}

			if (ImGui::BeginTabItem("Fighting" ) )
			{
				ImGui::Checkbox( "Auto-Kill on infect", &artemis::config::fighting::auto_kill_on_infected );

				ImGui::EndTabItem( );
			}

			if ( ImGui::BeginTabItem( "Cheat Window" ) )
			{
				ImGui::Text( "To enable the Cheat Window, press Shift and F1." );
				ImGui::Text( "This can cause bans!" );

				ImGui::EndTabItem( );
			}

#ifdef DEBUG
			if ( ImGui::BeginTabItem( "Debug" ) )
			{

				ImGui::EndTabItem( );
			}
#endif
			ImGui::EndTabBar( );
		}
		ImGui::End( );
	}

	cheatCallback( );
	ImGui::Render();

	pContext->OMSetRenderTargets(1, &mainRenderTargetView, NULL);
	ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
	return oPresent(pSwapChain, SyncInterval, Flags);
}

DWORD WINAPI MainThread(LPVOID lpReserved)
{
	bool init_hook = false;
	do
	{
		if (kiero::init(kiero::RenderType::D3D11) == kiero::Status::Success)
		{
			kiero::bind(8, (void**)& oPresent, hkPresent);
			init_hook = true;
		}
	} while (!init_hook);
	return TRUE;
}

BOOL WINAPI DllMain(HMODULE hMod, DWORD dwReason, LPVOID lpReserved)
{
	hModule = hMod;
	switch (dwReason)
	{
	case DLL_PROCESS_ATTACH:
		DisableThreadLibraryCalls(hMod);
		CreateThread(nullptr, 0, MainThread, hMod, 0, nullptr);
		break;
	case DLL_PROCESS_DETACH:
		kiero::shutdown();
		break;
	}
	return TRUE;
}